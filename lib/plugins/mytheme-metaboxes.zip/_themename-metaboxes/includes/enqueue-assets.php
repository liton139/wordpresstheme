<?php 



function mytheme_metaboxes_admin_scripts(){
    global $pagenow;
    if ($pagenow !== 'post.php') return;
    wp_enqueue_style('mytheme-metaboxes-admin-stylesheet', plugins_url(
        'mytheme-metaboxes/dist/assets/css/admin.css'), array(), '1.0.0','all');

    wp_enqueue_script('mytheme-metaboxes-admin-scripts', plugins_url(
        'mytheme-metaboxes/dist/assets/js/admin.js'), array('jquery'), '1.0.0', true);
}

add_action ('admin_enqueue_scripts', 'mytheme_metaboxes_admin_scripts');