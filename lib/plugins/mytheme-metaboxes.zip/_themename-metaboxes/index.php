<?php
/*
 * Plugin Name:       mytheme metaboxes
 * Plugin URI:        
 * Description:       Adding Metaboxes for mytheme
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Rafiqul Islam
 * Author URI:        https://liton139
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       mytheme-metaboxes
 * Domain Path:       /languages
 */

if( !defined('WPINC')) {
    die;
}

include_once('includes/metaboxes.php');
require_once('includes/enqueue-assets.php');