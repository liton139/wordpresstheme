<form role="search" method="get" class="c-search-form" action="<?php echo esc_url( home_url( '/' )); ?>">
    <label class="c-search-form__label">
        <span class="screen-reader-text"><?php esc_html_x( 'search for:', 'label', 'mytheme' ); ?></span>
        <input type="search" class="c-search-form__field" placeholder="<?php echo esc_attr_x( 'Search & help', 'placeholder', 'mytheme' ) ?>" value="<?php echo esc_attr(get_search_query());?>"name="s"/>
    </label>
    <button class="c-search-form__button" type="submit"><span class="u-screen-reader-text"><?php echo esc_html_x( 'Search', 'submit button', 'mytheme' ); ?></span><i class="fas fa-search" aria-hidden="true"></i>
    </button>
    <?php echo 'Button is here'; ?>
</form>
