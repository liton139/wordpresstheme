<aside role ="complementary">
    <?php dynamic_sidebar( 'primary-sidebar' );?>

</aside>